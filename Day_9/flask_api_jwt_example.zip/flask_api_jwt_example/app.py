from flask import  *
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash,check_password_hash
import jwt
from datetime import datetime,timedelta
from functools import wraps
import traceback
import uuid

app=Flask(__name__)

app.config["SECRET_KEY"]="thisisyear2022"

app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:///database.db"


db=SQLAlchemy(app)

class User(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    public_id=db.Column(db.String(50),unique=True)
    name=db.Column(db.String(200))
    email=db.Column(db.String(200),unique=True)
    contact=db.Column(db.String(200),unique=True)
    address=db.Column(db.String(500))
    password=db.Column(db.String(100))

class Item(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name = db.Column(db.String(200))
    description=db.Column(db.String(500))
    created=db.Column(db.DateTime,default=datetime.now)

#decorator function for verifiying jwt
def token_verify(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token=None
        if 'x-access-token' in request.headers:
            token=request.headers['x-access-token']

        if not  token:
            return make_response("Token is Missing!",404)
        try:
            data=jwt.decode(token,app.config["SECRET_KEY"],algorithms="HS256")
            current_user=User.query.filter_by(public_id=data["public_id"]).first()
        except Exception:
            traceback.print_exc()
            return  make_response("Token is invalid!",401)

        #returning current user details back to route
        return f(current_user, *args, **kwargs)

    return decorated

# signup
@app.route('/signup',methods=["POST"])
def signup():
    data=request.form
    name=data.get("name")
    email=data.get("email")
    contact=data.get("contact")
    address=data.get("address")
    password=data.get("password")

    user=User.query.filter_by(email=email).first()
    if not user:
        user=User(
            public_id=str(uuid.uuid4()),
            name=name,
            email=email,
            contact=contact,
            address=address,
            password=generate_password_hash(password)
        )
        try:
            db.session.add(user)
            db.session.commit()
            return make_response("Successfully Added User!",201)
        except:
            return make_response("Failed to Add User!",409)
    else:
        return make_response("User Already Present!", 202)

@app.route("/login",methods=["POST"])
def login():
    auth=request.form

    if not auth or not auth.get("email") or not auth.get("password"):
        return make_response("Cannot Verify! Please Enter Valid Records",401)

    user = User.query.filter_by(email=auth.get('email')).first()

    if not user:
        return make_response("User not found", 401)

    if check_password_hash(user.password,auth.get("password")):

        token=jwt.encode({
            'public_id':user.public_id,
            'exp': datetime.now()+timedelta(minutes=30)
        },app.config["SECRET_KEY"])

        return make_response(jsonify({'token':token}),201)

    return make_response("Cannot Find User Please Register!", 201)


@app.route('/user', methods =['GET'])
@token_verify
def get_all_users(current_user):
    users = User.query.all()
    res = []
    for user in users:
        res.append({
			'public_id': user.public_id,
			'name' : user.name,
			'email' : user.email
		})

    return jsonify({'users': res})

@app.route('/add_item', methods =['POST'])
@token_verify
def add_item(current_user):
    data = request.form
    name = data.get("name")
    description=data.get("description")
    item = Item(
        name=name,
        description=description
    )
    try:
        db.session.add(item)
        db.session.commit()
        return make_response("Successfully Added Item!", 201)
    except:
        return make_response("Failed to Add Item!", 409)

@app.route('/items', methods =['GET'])
@token_verify
def get_all_items(current_user):
    items = Item.query.all()
    res = []
    for i in items:
        res.append({
			'name' : i.name,
			'description' : i.description,
            'created':i.created
		})

    return jsonify({'items': res})

if __name__=="__main__":
    app.run(debug=True)

