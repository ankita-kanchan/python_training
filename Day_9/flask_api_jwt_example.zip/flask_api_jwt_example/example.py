
# def myfun(fun): #decorator
#     def data():
#         print("got decorated")
#         fun()
#     return data
#
# def demo():
#     print("this is demo")
#
# #decorating demo function
# call_fun=myfun(demo)
# call_fun()

def fun(*args):
   for i in args:
       print(i)

fun(1,2,3,4,5)

fun(name="Ankita")

def fun(**kwargs):
    print(kwargs["name"])

fun(name="Ankita")

