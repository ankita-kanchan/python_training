from flask  import *
from flask_sqlalchemy import SQLAlchemy

app=Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:///database.db"

db =SQLAlchemy(app)

class Movies(db.Model):
    __tablename__="movies"
    id=db.Column(db.Integer,primary_key=True)
    title=db.Column(db.String(200),nullable=False) #cannot be empty
    year = db.Column(db.Integer, nullable=False)
    genre = db.Column(db.String(200), nullable=False)

    def getJson(self):
        return {"id": self.id,"title":self.title,"year":self.year,'genre':self.genre}

def get_all():
    all_movies=Movies.query.all()
    res=[]
    for movie in all_movies:
        res.append(Movies.getJson(movie))
    return res

def add_movies(title,year,genre):
    new_movie=Movies(title=title,year=year,genre=genre)
    try:
        db.session.add(new_movie)
        db.session.commit()
        return "Movie Added Successfully!"
    except:
        return "Unable to create movie"

def get_movie(id):
    movie=Movies.query.filter_by(id=id).first()
    return Movies.getJson(movie)

def update_movies(id,title,year,genre):
    movie=Movies.query.filter_by(id=id).first()
    movie.title=title
    movie.year=year
    movie.genre=genre
    try:
        db.session.commit()
        return "Movie Updated Successfully!"
    except:
        return "Unable to update movie!"

def delete_movies(id):
    try:
        Movies.query.filter_by(id=id).delete()
        db.session.commit()
        return "Movie Deleted Successfully!"
    except:
        return "Unable to delete movie!"