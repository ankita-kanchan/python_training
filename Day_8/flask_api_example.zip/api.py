from  app import *

@app.route('/movies',methods=["GET"])
def get_all_movies():
    return jsonify({"movies":get_all()})

@app.route('/add_movie',methods=["POST"])
def add_movie():
    request_data=request.get_json()
    msg=add_movies(request_data["title"],request_data["year"],request_data["genre"])
    response=Response(msg,201,mimetype="application/json") #mime type for identifing json data
    return response

@app.route('/get_movie',methods=["POST"])
def get_movie_data():
    request_data=request.get_json()
    movie=get_movie(request_data["id"])
    return jsonify(movie)

@app.route('/get_movie/<int:id>')
def get_movie_data_get(id):
    movie=get_movie(id)
    return jsonify(movie)

@app.route('/update_movie',methods=["POST"])
def update_movie():
    request_data=request.get_json()
    msg=update_movies(request_data["id"],request_data["title"],request_data["year"],request_data["genre"])
    response=Response(msg,status=200,mimetype="application/json")
    return response

@app.route('/delete_movie',methods=["POST"])
def delete_movie():
    request_data=request.get_json()
    msg=delete_movies(request_data["id"])
    response=Response(msg,status=200,mimetype='application/json')
    return response

if __name__ =="__main__":
    app.run(debug=True)