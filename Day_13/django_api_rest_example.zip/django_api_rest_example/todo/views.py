from django.shortcuts import render
from .models import Todo
from todo.serializers import TodoSerializer
# Create your views here.
from rest_framework.generics import CreateAPIView
from rest_framework.generics import ListAPIView
from rest_framework.generics import UpdateAPIView
from rest_framework.generics import DestroyAPIView
from rest_framework import pagination
class CreateTodoAPIView(CreateAPIView):
    queryset = Todo.objects.all()
    serializer_class = TodoSerializer

class ListTodoAPIView(ListAPIView):
    queryset = Todo.objects.all()
    serializer_class = TodoSerializer
    pagination_class=pagination.LimitOffsetPagination
    filter_fields=(
        'status',
        'created'
    )
    search_fields=(
        '^title',
    )

    #^ start with
    #= exact match
    #@ full text search
    #$ regex search
    ordering_fields=(
        'created'
    )


class UpdateTodoAPIView(UpdateAPIView):
    queryset = Todo.objects.all()
    serializer_class = TodoSerializer

class DeleteTodoAPIView(DestroyAPIView):
    queryset = Todo.objects.all()
    serializer_class = TodoSerializer