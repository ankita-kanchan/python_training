from django.db import models

# Create your models here.

class Customers(models.Model):
    id=models.IntegerField(max_length=10,primary_key=True)
    name=models.CharField(max_length=200)
    email=models.EmailField(max_length=500)
    contact=models.CharField(max_length=10)
    address=models.CharField(max_length=500)

    class Meta:
        db_table="customers"