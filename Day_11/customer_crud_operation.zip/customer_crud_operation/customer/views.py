from django.shortcuts import render,redirect,HttpResponse
from customer.forms import CustomerForm
from customer.models import Customers
# Create your views here.

def index(request):
    customer=Customers.objects.all()
    return render(request,'index.html',{'customer':customer})

def add(request):
    if request.method=="POST":
        form=CustomerForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect('/')
            except:
                return HttpResponse("Customer Add Operation Failed!")
    else:
        form=CustomerForm()
    return render(request,'add.html',{'form':form})

def update(request,id):
    if request.method=="POST":
        customer=Customers.objects.get(id=id)
        form=CustomerForm(request.POST,instance=customer)
        if form.is_valid():
            form.save()
            return redirect('/')
    else:
        customer=Customers.objects.get(id=id)
    return render(request,'update.html',{'customer':customer})

def delete(request,id):
    customer=Customers.objects.get(id=id)
    customer.delete()
    return redirect('/')

def setSesssion(request):
    request.session["name"]="Ankita"
    request.session["email"]="demo@gmail.com"
    return HttpResponse("Session is set")

def getSession(request):
    name=request.session["name"]
    email = request.session["email"]
    return HttpResponse(name+" "+email)

def setCookies(request):
    response=HttpResponse("Cookie is set!")
    response.set_cookie('user_name','ankita@1234')
    return response

def getCookie(request):
    c=request.COOKIES['user_name']
    return HttpResponse("user name is "+c)
