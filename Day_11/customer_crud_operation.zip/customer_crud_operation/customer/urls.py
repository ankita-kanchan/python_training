
from django.contrib import admin
from django.urls import path
from customer import views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index,name="customer"),
    path('add',views.add,name="add"),
    path('update/<int:id>',views.update,name='update'),
    path('delete/<int:id>',views.delete,name='delete'),
    path('setsession',views.setSesssion,name="session"),
    path('getsession',views.getSession,name="get"),
    path('setcookie',views.setCookies,name="cookies"),
    path('getcookie', views.getCookie, name="getcookies"),
]
