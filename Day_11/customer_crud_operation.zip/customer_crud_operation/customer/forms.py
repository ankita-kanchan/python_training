from django import forms
from customer.models import Customers

class CustomerForm(forms.ModelForm):
    id=forms.IntegerField(label="Enter Customer ID")
    name=forms.CharField(label="Enter the name")
    email = forms.EmailField(label="Enter your Email")
    contact = forms.CharField(label="Enter your Contact No.")
    address = forms.CharField(label="Enter the Address")
    class Meta:
        model=Customers # model name
        fields="__all__" # validating
