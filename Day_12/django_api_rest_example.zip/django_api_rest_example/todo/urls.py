from django.contrib import admin
from django.urls import path,include
from todo import views
urlpatterns = [
    path("create/", views.CreateTodoAPIView.as_view(), name="todo_create"),
    path("", views.ListTodoAPIView.as_view(), name="todo_list"),
    path("update/<int:pk>/", views.UpdateTodoAPIView.as_view(), name="todo_update"),
    path("delete/<int:pk>/", views.DeleteTodoAPIView.as_view(), name="todo_delete"),
]