from django.contrib import admin
from django.urls import path
from .views import EmployeeCreate,EmployeeRetrieve,EmployeeDetail,EmployeeUpdate,EmployeeDelete
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',EmployeeCreate.as_view(),name="EmployeeCreate"),
    path('retrieve/',EmployeeRetrieve.as_view(),name="EmployeeRetrieve"),
    path('<int:pk>',EmployeeDetail.as_view(),name="EmployeeDetail"),
    path('<int:pk>/update/',EmployeeUpdate.as_view(),name="EmployeeUpdate"),
    path('<int:pk>/delete/',EmployeeDelete.as_view(),name="EmployeeDelete")
]