from django.shortcuts import render

from .models import Employee
from .forms import EmployeeForm
from django.views.generic.edit import CreateView,DeleteView,UpdateView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView

#Creating generic view for add employee operation
class EmployeeCreate(CreateView):
    model = Employee
    fields = '__all__'
    success_url = "/retrieve"


class EmployeeRetrieve(ListView):
    model = Employee
    success_url = "/retrieve"

class EmployeeDetail(DetailView):
    model = Employee
    success_url = "/retrieve"

class EmployeeUpdate(UpdateView):
    model = Employee
    template_name_suffix = "_update"
    fields = '__all__'
    success_url = "/retrieve"

class EmployeeDelete(DeleteView):
    model = Employee
    success_url = '/retrieve'