from django.contrib import admin
from django.urls import path
from .views import TodoCreate,TodoRetrieve,TodoDetail
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',TodoCreate.as_view(),name="TodoCreate"),
    path('retrieve/',TodoRetrieve.as_view(),name="TodoRetrieve"),
    path('<int:pk>',TodoDetail.as_view(),name="TodoDetail"),

]