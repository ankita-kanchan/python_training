from django.shortcuts import render

from .models import Todo
from .forms import TodoForm
from django.views.generic.edit import CreateView,DeleteView,UpdateView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView

#Creating generic view for add employee operation
class TodoCreate(CreateView):
    model = Todo
    fields = '__all__'
    success_url = "/todo/retrieve"


class TodoRetrieve(ListView):
    model = Todo
    success_url = "/todo/retrieve"

class TodoDetail(DetailView):
    model = Todo
    success_url = "/todo/retrieve"