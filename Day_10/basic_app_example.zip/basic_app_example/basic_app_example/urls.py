
from django.contrib import admin
from django.urls import path,include

admin.site.site_header="My Admin"
admin.site.site_title="My Admin"
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',include('home.urls')) #including home app urlConfs in project urls
]
