from django.contrib import admin
from home.models import Users
# Register your models here.
admin.site.register(Users)