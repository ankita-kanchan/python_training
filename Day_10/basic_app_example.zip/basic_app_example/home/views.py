from django.shortcuts import render,HttpResponse

# Create your views here.
from home.models import Users
from datetime import datetime
from django.contrib import messages

def index(request):
    data={"msg":"This is home page"}
    return render(request,'index.html',data)

def about(request):
    return HttpResponse("Hello This is about us")

def contact(request):
    if request.method=="POST":
        name=request.POST.get("name")
        email=request.POST.get("email")
        contact=request.POST.get("contact")
        message=request.POST.get("message")
        try:
            user=Users(name=name,email=email,contact=contact,message=message,date=datetime.now())
            user.save()
            messages.success(request,"User Added Successfully!")
        except:
            messages.error(request, "User Add Failed!")

    return render(request,'contact.html')