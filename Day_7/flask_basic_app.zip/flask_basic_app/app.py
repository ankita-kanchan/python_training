from flask import  Flask,render_template,redirect,url_for,request
app=Flask(__name__)

#rule is url binding to the function
#options is list of parameters
@app.route('/') # app.route(rule,options)
def index():
    return render_template('index.html')

@app.route('/user')
def user_data():
    return "hello user"

#url binding
@app.route('/hi/<name>')
def greet(name):
    if name=="user":
        return redirect(url_for('user_data')) #function name
    else:
        return "Hello dear " + name


@app.route('/task/<float:taskID>')
def display(taskID):
    return "task id is "+str(taskID)

@app.route("/login",methods=["POST","GET"])
def login():
    if request.method =="POST":
        user_email=request.form['email']
        return  redirect(url_for('output',name=user_email))
    else:
        user_email=request.args.get("email")
        return redirect(url_for('output', name=user_email))

@app.route("/output/<name>")
def output(name):
    return "Welcome "+name

if __name__ == "__main__":
    app.run(debug=True)

